ALTER TABLE `player` CHANGE `loaded_magazines` `loaded_magazines` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `player` CHANGE `handgun_items` `handgun_items` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `player` CHANGE `primary_weapon_items` `primary_weapon_items` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `player` CHANGE `secondary_weapon_items` `secondary_weapon_items` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;